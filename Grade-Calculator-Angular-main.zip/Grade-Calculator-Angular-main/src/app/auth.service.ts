
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  register(email: string, password: string) {
    // Implement user registration logic
  }

  login(email: string, password: string) {
    // Implement user login logic
  }
}
