export interface Student {
    name: string;
    grades: {
      math: number;
      science: number;
      english: number;
    };
  }
  